document.addEventListener("keydown",function(e){82===e.keyCode&&(window.location.href="/rick.html")});
